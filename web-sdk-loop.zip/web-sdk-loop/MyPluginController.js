// myPluginController.js
import ApiService from './ApiService.js';

class MyPluginController {
    constructor() {
        // Initialize the model (ApiService)
        this.apiService = new ApiService('http://13.232.216.75/whistle-follow-utils/pixel.php?linkid=8b604261e9a979e2da1111d186e883e1');
    }

    callApi(data) {
        // Call the API through the model
        this.apiService.callApi(data)
            .then(jsonData => {
                // Handle the API response
                console.log('API Response:', jsonData);
            })
            .catch(error => {
                // Handle errors
                console.error(error.message);
            });
    }
}

// Export the MyPluginController class
export default MyPluginController;
