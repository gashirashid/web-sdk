// apiService.js
class ApiService {
    constructor(apiUrl) {
        this.apiUrl = apiUrl;
        this.defaultData = this.getDefaultData();
    }

    async getDefaultData() {
        const domain = window.location.hostname;
        const ip = await this.getUserIP();
        const useragent = navigator.userAgent;
        console.log(domain,'domain')
        return {
            domain,
            ip,
            useragent,
        };
    }

    async getUserIP() {
        try {
            // Use a third-party service to fetch the user's IP address
            const response = await fetch('https://api64.ipify.org?format=json');
            const data = await response.json();
            console.log(data,'ip')
            return data.ip || '127.0.0.1'; // Default to localhost if IP is not available
        } catch (error) {
            console.error('Error fetching IP:', error.message);
            return '127.0.0.1'; // Default to localhost if there's an error
        }
    }

    callApi(data) {
        // Merge default data with provided data
        const requestData = { ...this.defaultData, ...data };

        const method = 'GET'; // You can change this to 'GET' or 'HEAD' as needed
        console.log('here')
        // Ensure that 'GET' and 'HEAD' requests don't have a request body
        const body = method === 'GET' || method === 'HEAD' ? undefined : JSON.stringify(requestData);

        return fetch(this.apiUrl, {
            method,
            // headers: {
            //     'Content-Type': 'application/json',
            // },
            body,
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }
            console.log(response);
            return response.json();
        })
        .catch(error => {
            throw new Error(`There was a problem with the API request: ${error.message}`);
        });
    }
}

export default ApiService;
